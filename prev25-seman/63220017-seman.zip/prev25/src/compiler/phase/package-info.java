/**
 * Compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.phase;
