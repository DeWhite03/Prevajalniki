/**
 * The compiler for the Prev25 programming language.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler;
