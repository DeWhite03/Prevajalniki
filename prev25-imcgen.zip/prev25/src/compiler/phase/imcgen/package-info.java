/**
 * Intermediate code generation.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.phase.imcgen;
