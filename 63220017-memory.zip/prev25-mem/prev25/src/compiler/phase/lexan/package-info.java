/**
 * Lexical analysis.
 */
package compiler.phase.lexan;
